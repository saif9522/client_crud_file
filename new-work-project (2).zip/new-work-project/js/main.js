// function addRecord() {
//     var empleyeename = document.getElementById("empleyeename") .value;

//     if(Name == ""){
//         alert("this is requred");
//         return false;
//     }
//     console.log()
// }

var x = 0;
var nama = [''];

var a = 0;
var  number = [''];


function clickFun(){
  empleyeename();
  Annualsalary();
  ondepartment();
  theDate()
};

function empleyeename() {
nama[x] = document.getElementById("empleyeename").value;
x++;

 document.getElementById("empleyeename").value = "";
  var e = '';   
    
   for (var y=0; y <nama.length; y++)
   {
     e +=  y + " "+ " " + nama[y] + "<br/> ";
   }
   document.getElementById("hasil").innerHTML = e;

 };

function Annualsalary() {
  number[a] = document.getElementById("Annualsalary").value;
  a++;
  // alert('this required');
   document.getElementById("Annualsalary").value = "";
    var f = '';   
      
     for (var b=0; b<number.length; b++)
     {
       f +=  b + " "+ " " + number[b] + "<br/> ";
     }
     document.getElementById("salary").innerHTML = f;

  };

// on change data

var select = document.getElementById("Department"),
    showOption = document.querySelector('#manage_name');

select.addEventListener('change', function ondepartment(){
  showOption.textContent = "" + this.value;
});

// date

function theDate(what) {
  let dateObj = new Date(what.value);
  let pickedDate = showDate(dateObj);
  // pickedDate may be yesterday's date
  console.log("picked date is " + (pickedDate || 'empty!'));
  document.getElementById('date-change').innerHTML = (pickedDate || "empty!");
  document.getElementbyId('date').style.display = "block";
};

function showDate(theDate) {
  console.log("typeof theDate = " + typeof theDate);
  if (typeof theDate == 'object') {

    return (theDate.getMonth() + 1) + "-" + theDate.getDate() + "-" + theDate.getFullYear();
  }
};


//  remove 

function removeClass() {
  var element = document.getElementById("removedata");
  alert("this delete data")
  element.remove("employee_details");
}

function aadfunction() {
  var x = document.getElementById("myDIV");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

// calcultaler
 function Calculate(){
     var a=parseInt(document.getElementById("txta").value);
     var b=parseInt(document.getElementById("txtb").value);

     var c=a+b;
    document.getElementById("txtc").value=""+c;
}

